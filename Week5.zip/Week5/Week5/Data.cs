﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week5
{
    class Data
    {

        public uint Value2 { get; set; }

        public string Value1 { get; set; }
        public override string ToString()
        {
            return Value1 + ":" + Value2.ToString();
        }

    }
}
